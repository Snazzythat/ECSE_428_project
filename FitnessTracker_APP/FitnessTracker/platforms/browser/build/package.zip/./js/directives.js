angular.module('starter.directives', [])

.directive('blankDirective', [function(){

}]);
