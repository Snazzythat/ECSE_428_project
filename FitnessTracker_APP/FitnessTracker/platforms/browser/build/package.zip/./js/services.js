angular.module('starter.services', [])

.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}]);
